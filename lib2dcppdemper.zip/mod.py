#!/usr/bin/env python3

import os
import shutil
import subprocess
import sys

CYAN = '\033[96m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
RED = '\033[91m'
WHITE = '\033[97m'
BOLD = '\033[1m'
DIM = '\033[2m'
RESET = '\033[0m'

print(f"""
{CYAN}╔══════════════════════════════════════════════════════════════╗
║  {WHITE}{BOLD}DZ Security Lab - lib2dcppdemper Installer{RESET}{CYAN}              ║
╚══════════════════════════════════════════════════════════════════╝{RESET}
""")

def check_and_install_requirements():
    print(f"{CYAN}┌──────────────────────────────────────────────────────────┐{RESET}")
    print(f"{CYAN}│{WHITE} {BOLD}🔍 Checking Required Tools{RESET}{CYAN}                        │{RESET}")
    print(f"{CYAN}├──────────────────────────────────────────────────────────┤{RESET}")
    
    required_tools = {
        'gcc': 'gcc',
        'make': 'make', 
        'readelf': 'binutils',
        'objdump': 'binutils',
        'c++filt': 'binutils'
    }
    
    missing_tools = []
    
    for tool, package in required_tools.items():
        check = subprocess.run(f"which {tool}", shell=True, capture_output=True, text=True)
        
        if check.returncode == 0 and check.stdout.strip():
            print(f"{CYAN}│{GREEN} ✅ {tool:<10} {DIM}found{RESET}{CYAN}                         │{RESET}")
        else:
            print(f"{CYAN}│{RED} ❌ {tool:<10} {DIM}not found{RESET}{CYAN}                     │{RESET}")
            if package not in missing_tools:
                missing_tools.append(package)
    
    if missing_tools:
        print(f"{CYAN}├──────────────────────────────────────────────────────────┤{RESET}")
        print(f"{CYAN}│{YELLOW} 📦 Installing missing packages...{RESET}{CYAN}               │{RESET}")
        print(f"{CYAN}│   {DIM}Updating package lists...{RESET}{CYAN}                  │{RESET}")
        subprocess.run("pkg update -y", shell=True, capture_output=True)
        
        for package in set(missing_tools):
            print(f"{CYAN}│   {DIM}Installing {package}...{RESET}{CYAN}                       │{RESET}")
            result = subprocess.run(f"pkg install {package} -y", shell=True, capture_output=True, text=True)
            
            if result.returncode == 0:
                print(f"{CYAN}│   {GREEN}✅ {package} installed successfully{RESET}{CYAN}          │{RESET}")
            else:
                print(f"{CYAN}│   {RED}❌ Failed to install {package}{RESET}{CYAN}               │{RESET}")
        
        print(f"{CYAN}├──────────────────────────────────────────────────────────┤{RESET}")
        print(f"{CYAN}│{WHITE} 🔄 Verifying installations...{RESET}{CYAN}                  │{RESET}")
        
        for tool, package in required_tools.items():
            check = subprocess.run(f"which {tool}", shell=True, capture_output=True, text=True)
            if check.returncode == 0 and check.stdout.strip():
                print(f"{CYAN}│{GREEN} ✅ {tool:<10} {DIM}now available{RESET}{CYAN}                 │{RESET}")
            else:
                print(f"{CYAN}│{RED} ❌ {tool:<10} {DIM}still missing{RESET}{CYAN}                │{RESET}")
    else:
        print(f"{CYAN}├──────────────────────────────────────────────────────────┤{RESET}")
        print(f"{CYAN}│{GREEN} ✅ All required tools are already installed!{RESET}{CYAN}      │{RESET}")
    
    print(f"{CYAN}└──────────────────────────────────────────────────────────┘{RESET}\n")

check_and_install_requirements()

source = "/sdcard/Download/lib2dcppdemper"
home = os.environ.get('HOME', '/data/data/com.termux/files/home')
dest = os.path.join(home, "lib2dcppdemper")

if not os.path.exists(source):
    print(f"{RED}❌ Error: lib2dcppdemper not found in /sdcard/Download/{RESET}")
    sys.exit(1)

print(f"{YELLOW}⏳ Copying...{RESET}")
shutil.copy2(source, dest)

os.remove(source)
print(f"{GREEN}✅ Copied and removed from source{RESET}")

os.chmod(dest, 0o755)
print(f"{GREEN}✅ Permissions set{RESET}")

print(f"""
{CYAN}════════════════════════════════════════════════════════════════{RESET}

{GREEN}✅ Installation complete!{RESET}
{CYAN}📁 Location: {dest}{RESET}

{CYAN}════════════════════════════════════════════════════════════════{RESET}

{WHITE}Commands:{RESET}

  {CYAN}./lib2dcppdemper /2{RESET}  {DIM}# Fast mode{RESET}
  {CYAN}./lib2dcppdemper /1{RESET}  {DIM}# Accurate mode (slow){RESET}
  {CYAN}./lib2dcppdemper /3{RESET}  {DIM}# Full ARM64 disassembly{RESET}
  {CYAN}./lib2dcppdemper -d 0xADDR{RESET}  {DIM}# Disassemble single function{RESET}

  {CYAN}./lib2dcppdemper -f /path/to/lib.so /2{RESET}  {DIM}# Specify library{RESET}
  {CYAN}./lib2dcppdemper -o output.cs /2{RESET}  {DIM}# Specify output{RESET}

  {CYAN}./lib2dcppdemper -h{RESET}  {DIM}# Help{RESET}

{CYAN}════════════════════════════════════════════════════════════════{RESET}

{GREEN}▀▄ DZ Security Lab ▄▀{RESET}
""")

print(f"{CYAN}📁 Changing to: {home}{RESET}")

os.chdir(home)
subprocess.run(["bash"], cwd=home)